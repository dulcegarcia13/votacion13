
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        // Crear el JTable
        JTable table = new JTable();

        // Crear el modelo de la tabla
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Candidato");
        model.addColumn("Votos");

        // Leer el archivo de texto
        try {
            BufferedReader reader = new BufferedReader(new FileReader("eleccion1.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                model.addRow(data);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Asignar el modelo a la tabla
        table.setModel(model);

        // Sumar los valores de la columna "votos"
        int totalVotos = 0;
        for (int i = 0; i < model.getRowCount(); i++) {
            int votos = Integer.parseInt(model.getValueAt(i, 1).toString());
            totalVotos += votos;
        }

        // Mostrar el total de votos
        System.out.println("El total de votos es: " + totalVotos);

        // Mostrar la tabla en una ventana
        JFrame frame = new JFrame();
        frame.add(new JScrollPane(table));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
