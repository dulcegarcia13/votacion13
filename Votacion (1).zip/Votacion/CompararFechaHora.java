import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

public class CompararFechaHora {
   public static void main(String[] args) {
        // Obtener la fecha y hora actual
        LocalDate fechaActual = LocalDate.now();
        LocalTime horaActual = LocalTime.now();

        // Obtener la fecha y hora ingresadas por el usuario
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la fecha (AAAA-MM-DD): ");
        String fechaIngresada = scanner.nextLine();
        System.out.print("Ingrese la hora (HH:MM): ");
        String horaIngresada = scanner.nextLine();

        // Convertir la fecha y hora ingresadas a objetos LocalDate y LocalTime
        LocalDate fechaIngresadaObj = LocalDate.parse(fechaIngresada);
        LocalTime horaIngresadaObj = LocalTime.parse(horaIngresada);

        // Comparar las fechas y horas
        if (fechaIngresadaObj.equals(fechaActual) && horaIngresadaObj.equals(horaActual)) {
            System.out.println("La fecha y hora ingresadas son iguales a la fecha y hora actual.");
        } else if (fechaIngresadaObj.isBefore(fechaActual) || (fechaIngresadaObj.equals(fechaActual) && horaIngresadaObj.isBefore(horaActual))) {
            System.out.println("La fecha y hora ingresadas son menores que la fecha y hora actual.");
        } else {
            System.out.println("La fecha y hora ingresadas son mayores que la fecha y hora actual.");
        }
    }
}
