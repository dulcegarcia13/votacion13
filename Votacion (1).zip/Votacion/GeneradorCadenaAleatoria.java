import java.util.Random;

public class GeneradorCadenaAleatoria {
    public static void main(String[] args) {
        String cadenaAleatoria = generarCadenaAleatoria(16);
        System.out.println("Cadena aleatoria: " + cadenaAleatoria);
    }

    public static String generarCadenaAleatoria(int longitud) {
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder cadena = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < longitud; i++) {
            int indice = random.nextInt(caracteres.length());
            char caracterAleatorio = caracteres.charAt(indice);
            cadena.append(caracterAleatorio);
        }

        return cadena.toString();
    }
}
