import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ModificarArchivoTexto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese el dato a buscar: ");
        String datoBuscado = scanner.nextLine();
        
        try {
            FileReader fileReader = new FileReader("archivo.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            
            StringBuilder stringBuilder = new StringBuilder();
            String linea;
            
            while ((linea = bufferedReader.readLine()) != null) {
                if (linea.contains(datoBuscado)) {
                    System.out.println("Dato encontrado: " + linea);
                    System.out.print("Ingrese el nuevo apellido: ");
                    String nuevoApellido = scanner.nextLine();
                    System.out.print("Ingrese el nuevo nombre: ");
                    String nuevoNombre = scanner.nextLine();
                    System.out.print("Ingrese el nuevo correo: ");
                    String nuevoCorreo = scanner.nextLine();
                    
                    linea = linea.replaceFirst("Apellido: .*", "Apellido: " + nuevoApellido);
                    linea = linea.replaceFirst("Nombre: .*", "Nombre: " + nuevoNombre);
                    linea = linea.replaceFirst("Correo: .*", "Correo: " + nuevoCorreo);
                }
                
                stringBuilder.append(linea);
                stringBuilder.append(System.lineSeparator());
            }
            
            bufferedReader.close();
            
            FileWriter fileWriter = new FileWriter("archivo.txt");
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            
            bufferedWriter.write(stringBuilder.toString());
            
            bufferedWriter.close();
            
            System.out.println("Archivo actualizado correctamente.");
        } catch (IOException e) {
            System.out.println("Error al leer o escribir en el archivo.");
            e.printStackTrace();
        }
        
        scanner.close();
    }
}
