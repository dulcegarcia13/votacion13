import java.io.*;

public class EliminarLineaTexto {
    public static void main(String[] args) {
        String archivo = "configuracion.txt";
        String datoABuscar = "12705405";

        try {
            File inputFile = new File(archivo);
            File tempFile = new File("temp.txt");

            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            String lineaActual;

            while ((lineaActual = reader.readLine()) != null) {
                // Verificar si la línea contiene el dato a buscar
                if (!lineaActual.contains(datoABuscar)) {
                    writer.write(lineaActual);
                    writer.newLine();
                }
            }

            writer.close();
            reader.close();

            // Reemplazar el archivo original con el archivo temporal
            inputFile.delete();
            tempFile.renameTo(inputFile);

            System.out.println("Se ha eliminado la línea que contiene el dato '" + datoABuscar + "' del archivo '" + archivo + "'.");
        } catch (IOException e) {
            System.out.println("Error al procesar el archivo: " + e.getMessage());
        }
    }
}
