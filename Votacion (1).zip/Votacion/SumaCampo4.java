
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class SumaCampo4 {
public static int suma = 0;
    public static void main(String[] args) {
        String archivo = "eleccion1.txt";
        String linea = "";
        String camposuma="";
       

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            while ((linea = br.readLine()) != null) {
                String[] campos = linea.split(",");
                suma += Integer.parseInt(campos[4]);
                //camposuma = campos[4];
                
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
System.out.println("El resultado total de la suma del campo 4 es: " +suma);
        
    }
}
