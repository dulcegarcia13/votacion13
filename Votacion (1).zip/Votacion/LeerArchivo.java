import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class LeerArchivo {

    public static void main(String[] args) {
        String archivo = "configuracion.txt";
        String[][] matriz = leerArchivo(archivo);
        
        // Imprimir la matriz
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static String[][] leerArchivo(String archivo) {
        String[][] matriz = null;
        BufferedReader br = null;
        String linea;
        int filas = 0;
        
        try {
            br = new BufferedReader(new FileReader(archivo));
            
            // Contar el número de filas en el archivo
            while ((linea = br.readLine()) != null) {
                filas++;
            }
            
            // Crear la matriz con el número de filas
            matriz = new String[filas][4];
            
            // Volver a leer el archivo para almacenar los campos en la matriz
            br = new BufferedReader(new FileReader(archivo));
            int fila = 0;
            
            while ((linea = br.readLine()) != null) {
                String[] campos = linea.split(",");
                
                // Almacenar los campos en la matriz
                for (int i = 0; i < campos.length; i++) {
                    matriz[fila][i] = campos[i];
                }
                
                fila++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        
        return matriz;
    }
}
